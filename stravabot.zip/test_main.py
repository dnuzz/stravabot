from main import handler

handler (context={"context":"context"},event={"event":"event"})
