stravalib is a Python 2.7 and 3.x library that provides a simple API for interacting
with the Strava activity tracking website.

Changes in 0.6.3
----------------
* Fixed update_activity to include description (#91)



