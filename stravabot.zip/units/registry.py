"""Global registry mapping unit specifiers to unit objects."""

REGISTRY = {}
